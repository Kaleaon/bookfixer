# Replaced when bundled into the fanfic plugin: only the EPUB writer is shipped.
from ..exceptions import FailedToDownload

from .writer_epub import EpubWriter


def getWriter(type, config, story):
    if type == "epub":
        return EpubWriter(config, story)
    raise FailedToDownload("(%s) is not a supported download format." % type)
